package com.capgemini.xyz.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity   //compulsory annotation
@Table(name = "transactions") //optional annotation
public class Transaction {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int Id;
	@Column(length=20)
	private int accNo;

	public int getAccNo() {
		return accNo;
	}

	private String type;
	@Column(length=20)
	private double amount, balance;

	public Transaction() {
	}

	public Transaction(int accNo, double amount, double balance, String type) {
		this.accNo = accNo;
		this.type = type;
		this.amount = amount;
		this.balance = balance;
	}

	@Override
	public String toString() {
		return "Transaction \naccNo=" + accNo + ", type=" + type
				+ ", amount=" + amount + ", balance=" + balance;
	}


}
