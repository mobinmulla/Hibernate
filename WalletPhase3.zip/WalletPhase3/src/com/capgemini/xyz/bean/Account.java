package com.capgemini.xyz.bean;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity   
@Table(name = "accounts") 
public class Account implements Serializable{
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(length=20)
	private int accNo;
	@Column(length=20)
	private String name;
	@Column(length=20)
	private long mobile;
	@Column(length=20)
	private String email;
	@Column(length=20)
	protected double balance;

	public Account() {
	}

	public Account(String name, long mobile, String email) {
		this.name = name;
		this.mobile = mobile;
		this.email = email;
	}

	@Override
	public String toString() {
		return "A/C No = " + accNo + "\nName = " + name + "\nMobile = "
				+ mobile + "\nEmail = " + email + "\nBalance = " + balance;
	}

	public int getAccNo() {
		return accNo;
	}

	public void setAccNo(int accNo) {
		this.accNo = accNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getMobile() {
		return mobile;
	}

	public void setMobile(long mobile) {
		this.mobile = mobile;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

}

