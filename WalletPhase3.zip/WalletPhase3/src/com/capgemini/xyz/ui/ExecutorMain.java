package com.capgemini.xyz.ui;

import java.util.Scanner;

import com.capgemini.xyz.bean.Account;
import com.capgemini.xyz.service.Validate;
import com.capgemini.xyz.service.ValidateInterface;

public class ExecutorMain {
	public static void main(String[] args) {
		ValidateInterface valid = new Validate();

		Scanner input = new Scanner(System.in);
		Account account = new Account();

		int choice;
		String name;
		long mobile;
		String email;
		double amount;

		for (;;) {
			System.out
					.println("Enter choice:\n1.Register New Customer\n2.Login\n3.Exit");
			choice = input.nextInt();
			switch (choice) {
			case 1:
				System.out.println("Enter Customer Name:");
				name = input.next();
				System.out.println("Enter Customer Contact Number:");
				mobile = input.nextLong();
				System.out.println("Enter Customer Email id:");
				email = input.next();

				account.setName(name);
				account.setMobile(mobile);
				account.setEmail(email);
				account.setBalance(1000);
				valid.openAccount(account);

				break;

			case 2:
				System.out.println("Please Enter your account number");
				int Accno = input.nextInt();
				try {
					valid.validateAccountNo(Accno);
					while (true) {
						System.out
								.println("What service would you like today :");
						System.out.println("1.Show Balance");
						System.out.println("2.Deposit");
						System.out.println("3.Withdraw");
						System.out.println("4.Tansfer Fund");
						System.out.println("5.Show Transaction");
						System.out.println("6.Exit");
						
						choice = Integer.parseInt(input.next());
						switch (choice) {
						case 1:
							System.out.println("Your Balance is:");
							System.out.println(valid.showBalance(Accno));
							break;
						case 2:
							System.out.println("Enter Deposit Amount:");
							amount = input.nextDouble();
							valid.deposit(Accno, amount);
							break;

						case 3:

							System.out
									.println("Enter Withdrew amount:");
							amount = input.nextDouble();
							valid.withdraw(Accno, amount);
							break;
						case 4:
							System.out
									.println("Please enter the Account number of the receiptent :");
							int accno = input.nextInt();
							System.out.println("Enter the Amount");
							amount = input.nextDouble();
							valid.fundTransfer(Accno, accno, amount);
							break;

						case 5:
							System.out.println("Transaction Details are:");
							valid.showTransaction(Accno);
							break;
						case 6:
							System.out
									.println("Thanks You");
							System.exit(0);
							break;

						default:
							System.out
									.println("Invalid choice ");
							break;
						}

					}
				} catch (Exception e) {
					System.out.println(e);
				}

				break;
			case 3:
				System.out.println("Thank You");
				System.exit(0);
				break;

			default:
				System.out.println("Thank you");
				break;
			}
		}

	}
}
