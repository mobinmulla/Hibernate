package com.capgemini.xyz.dao;

import java.util.List;

import javax.persistence.EntityManager;

import com.capgemini.xyz.bean.Account;
import com.capgemini.xyz.bean.Transaction;

public class StoreData implements StoreDataInterFace {
	// Scanner input = new Scanner(System.in);
	Account account = new Account();
	private EntityManager entityManager;

	public StoreData() {
		entityManager = JPAUtil.getEntityManager();
	}

	@Override
	public void openAccount(Account acc) {
		entityManager.persist(acc); // equivalent to insert query.
	}

	@Override
	public void deposit(int accID, double amount) {
		Account account = entityManager.find(Account.class, accID);
		double bal = account.getBalance();
		account.setBalance(bal + amount);
		entityManager.merge(account);
		
		Transaction t= new Transaction(accID,amount,account.getBalance(),"CR");
		entityManager.persist(t);

	}

	@Override
	public void withdraw(int accId, double amount) {
		Account account = entityManager.find(Account.class, accId);
		double bal = account.getBalance();
		if (bal < amount) {
			System.out.println("Insufficient Fund");
		} else {
			account.setBalance(bal - amount);
			Transaction t= new Transaction(accId ,amount,account.getBalance(),"DR");
			entityManager.persist(t);
			entityManager.merge(account);
		}
		

	}

	@Override
	public void commitTransaction() {
		entityManager.getTransaction().commit();

	}

	@Override
	public void beginTransaction() {
		entityManager.getTransaction().begin();

	}

	@Override
	public boolean validateAccountNo(int accno) {
		Account au = entityManager.find(Account.class, accno);
		if (au != null) {
			Account account = entityManager.find(Account.class, accno);
			System.out.println(account);
			return true;
		} else {
			return false;
		}

	}

	@Override
	public void fundTransfer(int source, int target, double amount) {
		Account acc = entityManager.find(Account.class, source);
		double balance = acc.getBalance();
		if (balance < amount) {
			System.out.println("Insuficient fund");
		} else {
			deposit(target, amount);
			withdraw(source, amount);
		}

	}

	@Override
	public double showBalance(int accId) {
		Account account = entityManager.find(Account.class, accId);
		return account.getBalance();
	}

	@Override
	public void showTransaction(int accno) {
		System.out.println(accno);
		List<Transaction> list =  entityManager
				.createQuery("SELECT trans FROM Transaction trans WHERE trans.accNo=:transId ORDER BY trans.id",Transaction.class)
				.setParameter("transId", accno).getResultList();
		if(list.isEmpty()){
			System.out.println("list empty");
		}
		for (Transaction transaction : list) {
			System.out.println(transaction);
		}
		

	}

}
