package com.capgemini.xyz.dao;

import com.capgemini.xyz.bean.Account;

public interface StoreDataInterFace {
	int MIN_BALANCE = 0;


	void openAccount(Account acc);

	double showBalance(int accId) ;

	void deposit(int accID, double amount) ;

	void withdraw(int accId, double amount) ;

	public abstract void commitTransaction();

	public abstract void beginTransaction();
	
	boolean validateAccountNo(int accno);

	void fundTransfer(int source, int target, double amount);
	
	void showTransaction(int accno);

}
