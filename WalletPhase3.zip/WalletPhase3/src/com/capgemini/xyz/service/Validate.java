package com.capgemini.xyz.service;

import com.capgemini.xyz.bean.Account;
import com.capgemini.xyz.dao.StoreData;
import com.capgemini.xyz.dao.StoreDataInterFace;

public class Validate implements ValidateInterface {
	
	StoreDataInterFace store = new StoreData();

	@Override
	public boolean validateUserName(String userName) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean validatePassword(String password) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean validateMobile(String mobile) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean validateEmail(String email) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean validateEntry(String ch) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean validateAccId(String userAccId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void openAccount(Account acc) {
		store.beginTransaction();
		store.openAccount(acc);
		store.commitTransaction();

	}

	@Override
	public double showBalance(int accId) {
		
		return store.showBalance(accId);
	}

	@Override
	public void deposit(int accId, double amount) {
		store.beginTransaction();
		store.deposit(accId, amount);
		store.commitTransaction();

	}

	@Override
	public void showTransaction(int accno) {
		store.beginTransaction();
		store.showTransaction(accno);
		store.commitTransaction();

	}

	@Override
	public void withdraw(int accId, double amount) {
		store.beginTransaction();
		store.withdraw(accId, amount);
		store.commitTransaction();

	}

	@Override
	public void fundTransfer(int source, int target, double amount) {
		store.beginTransaction();
		store.fundTransfer(source, target, amount);
		store.commitTransaction();

	}

	@Override
	public Account findDetails(int AccNo) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void validateAccountNo(int accno) {
		store.beginTransaction();
		store.validateAccountNo(accno);
		store.commitTransaction();
		
	}


}
