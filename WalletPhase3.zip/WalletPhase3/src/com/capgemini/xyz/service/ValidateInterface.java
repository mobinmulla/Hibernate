package com.capgemini.xyz.service;

import com.capgemini.xyz.bean.Account;

public interface ValidateInterface {
	// Matches pattern string
	String ENTRY = "[1-7]{1}";
	String FIRST_CHOICE="[1-2]{1}";
	String ACC_NO = "[0-9]{7}";
	String PASSWORD =  "((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%]).{6,15})";
	String AMOUNT = "[0-9]{1,10}";
	String USER_NAME_PATTERN = "[a-zA-Z]{1,10}";
	String ADDRESS_PATTERN = "[A-Za-z]{1,25}";
	String MOBILE_PATTERN = "[0-9]{10}";
	String EMAIL_PATTERN = "^[\\w-\\+]+(\\.[\\w]+)*@[\\w-]+(\\.[\\w]+)*(\\.[a-z]{2,})$";

	boolean validateUserName(String userName);

	boolean validatePassword(String password);
	
	boolean validateMobile(String mobile);

	boolean validateEmail(String email);

	boolean validateEntry(String ch);

	boolean validateAccId(String userAccId);


	void openAccount(Account acc);

	double showBalance(int accId) ;

	void deposit(int accId, double amount);

	void showTransaction(int transactionId);

	void withdraw(int accId, double amount);

	void fundTransfer(int source, int target, double amount);

	Account findDetails(int AccNo);

	void validateAccountNo(int accno);

	//Account showUser(int accno);
}
